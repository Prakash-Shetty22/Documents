package training.iqgateway.messagingwebsocket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessagingWebsocketApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessagingWebsocketApplication.class, args);
	}

}

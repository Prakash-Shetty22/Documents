package training.iqgateway.authenticate.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import training.iqgateway.authenticate.models.User;

public interface UserRepository extends MongoRepository<User, Long> {
	
	User findByMobileNumber(Long mobileNumber);
	
}

package training.iqgateway.authenticate.repositories;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import training.iqgateway.authenticate.models.User;

@Component
public class CustomUserRepositoryImpl implements CustomUserRepository {
	
	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public boolean isIdExists(Long id) {
		Query query = new Query(Criteria.where("_id").is(id));
	    return mongoTemplate.exists(query, User.class);
	}

}

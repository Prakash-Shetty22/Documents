package training.iqgateway.authenticate.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import training.iqgateway.authenticate.models.User;
import training.iqgateway.authenticate.services.AuthenticateService;

@RestController
@CrossOrigin
@RequestMapping("/authenticate")
public class AuthenticateControllers {
	
	@Autowired
	private AuthenticateService authenticateService;
	
//	@PostMapping("/signup")
//	public ResponseEntity<?> signUp(@RequestBody User user) {
//		// Save the user data to MongoDB
//		return authenticateService.registerUser(user);
//	}
	
//	@PostMapping("/signup")
//	public User signUp(@RequestBody User user) {
//		// Save the user data to MongoDB
//		return authenticateService.registerUser(user);
//	}
	
	@PostMapping("/signup")
	public User signUp(@RequestBody User user) {
		// Save the user data to MongoDB
		return authenticateService.registerUser(user);
	}
	
	@PostMapping("login")
	public ResponseEntity<?> login(@RequestBody User loginUser) {
		return authenticateService.login(loginUser);
	}

}

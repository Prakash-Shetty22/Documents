package training.iqgateway.authenticate.repositories;

public interface CustomUserRepository {
	
	boolean isIdExists(Long id);
	
}

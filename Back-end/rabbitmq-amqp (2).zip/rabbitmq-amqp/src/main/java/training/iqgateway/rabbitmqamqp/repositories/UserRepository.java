package training.iqgateway.rabbitmqamqp.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import training.iqgateway.rabbitmqamqp.model.User;

public interface UserRepository extends MongoRepository<User, Long> {
	
	User findByMobileNumber(Long mobileNumber);
	
//	String findFullNameByMobileNumber(Long mobileNumber);
	
}

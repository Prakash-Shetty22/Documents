package training.iqgateway.rabbitmqamqp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication
@EnableMongoRepositories
public class RabbitmqAmqpApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabbitmqAmqpApplication.class, args);
	}

}

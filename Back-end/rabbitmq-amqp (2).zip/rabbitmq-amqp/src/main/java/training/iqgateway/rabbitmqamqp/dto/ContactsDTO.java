package training.iqgateway.rabbitmqamqp.dto;

public class ContactsDTO {
	
	private Long mobileNumber;
	private String name;
	private Integer unreadMessages;
	private String lastMessage;
	
	public ContactsDTO() {
		// TODO Auto-generated constructor stub
	}

	public ContactsDTO(Long mobileNumber, String name, Integer unreadMessages, String lastMessage) {
		super();
		this.mobileNumber = mobileNumber;
		this.name = name;
		this.unreadMessages = unreadMessages;
		this.lastMessage = lastMessage;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getUnreadMessages() {
		return unreadMessages;
	}

	public void setUnreadMessages(Integer unreadMessages) {
		this.unreadMessages = unreadMessages;
	}

	public String getLastMessage() {
		return lastMessage;
	}

	public void setLastMessage(String lastMessage) {
		this.lastMessage = lastMessage;
	}

	@Override
	public String toString() {
		return "ContactsDTO [mobileNumber=" + mobileNumber + ", name=" + name + ", unreadMessages=" + unreadMessages
				+ ", lastMessage=" + lastMessage + "]";
	}
	
}

package training.iqgateway.rabbitmqamqp.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import training.iqgateway.rabbitmqamqp.model.Message;

public interface MessageRepository extends MongoRepository<Message, String> {
	Message findByActors(String actors);
	
//	List<Message> findByIdEndingWith(String suffix);
	
//	@Query(value = "{ '_id': { $regex: ?0 } }", fields = "{ '_id' : 1 }")
//    List<String> findIdsByIdEndingWith(String suffix);
	
	List<Message> findMessagesByActorsEndingWith(String actorsSuffix);
	
}

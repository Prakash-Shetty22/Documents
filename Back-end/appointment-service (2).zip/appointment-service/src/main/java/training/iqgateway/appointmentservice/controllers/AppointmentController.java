package training.iqgateway.appointmentservice.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import training.iqgateway.appointmentservice.models.Appointment;
import training.iqgateway.appointmentservice.services.AppointmentService;

@RestController
@CrossOrigin
@RequestMapping("/appointments")
public class AppointmentController {
	
	@Autowired
	private AppointmentService appointmentService;
	
	@PostMapping("/add")
	public ResponseEntity<Map<String, String>> addAppointment(@RequestBody Map<String, String> appointment) {
		return appointmentService.addAppointment(appointment);
	}
	
	@PostMapping("/status")
	public List<Appointment> getAppointmentStatus(@RequestBody Map<String, String> searchCriteria) {
		return appointmentService.getAppointmentStatus(searchCriteria);
	}
	
	@PostMapping("/completed")
	public List<Appointment> getCompletedAppointments(@RequestBody Map<String, String> searchCriteria) {
		return appointmentService.getCompletedAppointments(searchCriteria);
	}
	
	@PostMapping("/completedOfHospital")
	public List<Appointment> getCompletedAppointmentsOfHospital(@RequestBody Map<String, String> searchCriteria) {
		return appointmentService.getCompletedAppointmentsOfHospital(searchCriteria);
	}
	
	@PostMapping("/getAll")
	public List<Appointment> getAppointments(@RequestBody Map<String, String> searchCriteria) {
		System.out.println("Inside");
		return appointmentService.getAppointments();
	}
	
//	@GetMapping("/getAll")
//	public List<Appointment> getAppointments(@RequestParam String mobileNumber) {
//		System.out.println("Inside");
//		return appointmentService.getAppointments();
//	}
	
	@PostMapping("/requests")
	public List<Appointment> getAppointmentRequests(@RequestBody Map<String, String> searchCriteria) {
		return appointmentService.getAppointmentRequests(searchCriteria);
	}
	
	@PostMapping("/sendRequest")
	public ResponseEntity<Map<String, String>> sendRequest(@RequestBody Appointment appointment) {
		System.out.println("Inside Send Request");
		return appointmentService.sendRequest(appointment);
	}
	
	@PostMapping("/acceptRequest")
	public ResponseEntity<Map<String, String>> acceptRequest(@RequestBody Appointment appointment) {
		return appointmentService.acceptRequest(appointment);
	}
	
	@PostMapping("/declineRequest")
	public ResponseEntity<Map<String, String>> declineRequest(@RequestBody Appointment appointment) {
		return appointmentService.declineRequest(appointment);
	}
	
	@PostMapping("/doctorsRequests")
	public List<Appointment> getRequestsOfDoctors(@RequestBody Map<String, String> searchCriteria) {
		return appointmentService.getRequestsOfDoctors(searchCriteria);
	}
	
	@PostMapping("/acceptedRequests")
	public List<Appointment> getAcceptedRequests(@RequestBody Map<String, String> searchCriteria) {
		return appointmentService.getAcceptedRequests(searchCriteria);
	}
	
	@PostMapping("/doctorApproval")
	public List<Appointment> getDoctorApprovals(@RequestBody Map<String, String> searchCriteria) {
		return appointmentService.getDoctorApprovals(searchCriteria);
	}
	
	@PostMapping("/sendToPatient")
	public ResponseEntity<Map<String, String>> sendToPatient(@RequestBody Appointment appointment) {
		return appointmentService.sendToPatient(appointment);
	}
	
	@PostMapping("/fixAppointment")
	public ResponseEntity<Map<String, String>> fixAppointment(@RequestBody Appointment appointment) {
		return appointmentService.fixAppointment(appointment);
	}
	
	@PostMapping("/remove")
	public ResponseEntity<Map<String, String>> removeAppointment(@RequestBody Appointment appointment) {
		return appointmentService.removeAppointment(appointment);
	}
	
	@PostMapping("/cancel")
	public ResponseEntity<Map<String, String>> cancelAppointment(@RequestBody Appointment appointment) {
		return appointmentService.cancelAppointment(appointment);
	}
	
	@PostMapping("/updatePatientRecord")
	public ResponseEntity<Map<String, String>> updatePatientRecord(@RequestBody Appointment appointment) {
		return appointmentService.updatePatientRecord(appointment);
	}
	
	@PostMapping("/treatmentOver")
	public ResponseEntity<Map<String, String>> treatmentOver(@RequestBody Appointment appointment) {
		return appointmentService.treatmentOver(appointment);
	}
}

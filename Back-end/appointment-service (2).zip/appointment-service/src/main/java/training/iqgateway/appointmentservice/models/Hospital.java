package training.iqgateway.appointmentservice.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("Hospital")
public class Hospital {
	
	@Id
	private String id;
    private String name;
    private String location;
    private Admin admin;

    public Hospital() {
		// TODO Auto-generated constructor stub
	}

    public Hospital(String id, String name, String location, Admin admin) {
		super();
		this.id = id;
		this.name = name;
		this.location = location;
		this.admin = admin;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	@Override
	public String toString() {
		return "Hospital [id=" + id + ", name=" + name + ", location=" + location + ", admin=" + admin + "]";
	}


	public static class Admin {
        private Long mobileNumber;
        private String fullName;

        public Admin() {
			// TODO Auto-generated constructor stub
		}
        
        public Admin(Long mobileNumber, String fullName) {
			super();
			this.mobileNumber = mobileNumber;
			this.fullName = fullName;
		}

		public String getFullName() {
			return fullName;
		}

		public void setFullName(String fullName) {
			this.fullName = fullName;
		}

		// additional constructor needed to handle deserialization of "$numberLong" field
        public void setMobileNumber(Long mobileNumber) {
            this.mobileNumber = mobileNumber;
        }

        // additional getter to handle serialization of "$numberLong" field
        public Long getMobileNumber() {
            return mobileNumber;
        }

		@Override
		public String toString() {
			return "Admin [mobileNumber=" + mobileNumber + ", fullName=" + fullName + "]";
		}
        
    }

}

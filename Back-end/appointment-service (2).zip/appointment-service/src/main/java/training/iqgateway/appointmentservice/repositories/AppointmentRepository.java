package training.iqgateway.appointmentservice.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import training.iqgateway.appointmentservice.models.Appointment;

public interface AppointmentRepository extends MongoRepository<Appointment, String> {
	/*In place of first one, I've used second one*/
//	List<Appointment> findByPatient_MobileNumberAndTreatmentCompletedIsFalseAndDateGreaterThan(Long mobileNumber,
//			String date);
	List<Appointment> findByPatient_MobileNumberAndTreatmentCompletedIsFalseAndShowIsTrue(Long mobileNumber);
	/*ends here*/
	
	List<Appointment> findByPatient_MobileNumberAndTreatmentCompletedIsTrue(Long mobileNumber);
	
	// List<Appointment>
	// findByTreatmentCompletedIsFalseAndDateGreaterThanAndPatient_MobileNumber(long
	// mobileNumber, String date);
	// List<Appointment>
	// findByTreatmentCompletedIsFalseAndPatient_MobileNumber(long
	// mobileNumber);
	// List<Appointment>
	// findByTreatmentCompletedIsFalseAndDateGreaterThan(String date);

	// List<Appointment>
	// findByDoctor_Hospital_Admin_MobileNumberAndRequestStatusAndDateAndTimeGreaterThanEqual(
	// Long mobileNumber, String requestStatus, String date, String time);
	// List<Appointment>
	// findByDoctor_Hospital_Admin_MobileNumberAndRequestStatusAndDateGreaterThanEqualOrDateEqualsAndTimeGreaterThanEqual(
	// Long mobileNumber, String requestStatus, String date, String time);

//	List<Appointment> findByDoctor_Hospital_Admin_MobileNumberAndRequestStatusAndDateGreaterThan(Long mobileNumber,
//			String requestStatus, String date);
//
//	List<Appointment> findByDoctor_Hospital_Admin_MobileNumberAndRequestStatusAndDateEqualsAndTimeGreaterThanEqual(
//			Long mobileNumber, String requestStatus, String date, String time);
	
	/*Instead of first two methods I'm using only third one*/
//	List<Appointment> findByDoctor_Hospital_Admin_MobileNumberAndSentToDoctorIsFalseAndDateGreaterThan(Long mobileNumber,
//			String date);
//
//	List<Appointment> findByDoctor_Hospital_Admin_MobileNumberAndSentToDoctorIsFalseAndDateEqualsAndTimeGreaterThanEqual(
//			Long mobileNumber, String date, String time);
	
	List<Appointment> findByDoctor_Hospital_Admin_MobileNumberAndSentToDoctorIsFalseAndRequestStatus(Long mobileNumber, String requestStatus);
	/*ends here*/
	List<Appointment> findByDoctor_Hospital_Admin_MobileNumberAndSentToDoctorIsFalseAndRequestStatusAndReschedulingRequestIsTrueAndReschedulingStatus(Long mobileNumber, String requestStatus, String reschedulingStatus);
	
	List<Appointment> findByDoctor_MobileNumberAndSentToDoctorIsTrueAndRequestStatus(Long mobileNumber, String requestStatus);
	List<Appointment> findByDoctor_MobileNumberAndSentToDoctorIsTrueAndReschedulingStatus(Long mobileNumber, String reschedulingStatus);
	
	List<Appointment> findByDoctor_Hospital_Admin_MobileNumberAndSentToDoctorIsTrueAndDoctorApprovalIsTrueAndSentToPatientIsFalse(Long mobileNumber);
	
	List<Appointment> findByDoctor_MobileNumberAndSentToPatientIsTrueAndTreatmentCompletedIsFalseAndRequestStatus(Long mobileNumber, String requestStatus);
	List<Appointment> findByDoctor_MobileNumberAndSentToPatientIsTrueAndTreatmentCompletedIsFalseAndReschedulingStatus(Long mobileNumber, String reschedulingStatus);

	List<Appointment> findByDoctor_Hospital_Admin_MobileNumberAndTreatmentCompletedIsTrue(Long mobileNumber);
}

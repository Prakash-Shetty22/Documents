package training.iqgateway.appointmentservice.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import training.iqgateway.appointmentservice.models.User;

public interface UserRepository extends MongoRepository<User, Long> {
	
	User findByMobileNumber(Long mobileNumber);
	
}

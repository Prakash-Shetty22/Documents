package training.iqgateway.appointmentservice.services;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import training.iqgateway.appointmentservice.models.Appointment;
import training.iqgateway.appointmentservice.models.Doctor;
import training.iqgateway.appointmentservice.models.User;
import training.iqgateway.appointmentservice.repositories.AppointmentRepository;
import training.iqgateway.appointmentservice.repositories.DoctorRepository;
import training.iqgateway.appointmentservice.repositories.UserRepository;

@Service
public class AppointmentService {

	@Autowired
	private AppointmentRepository appointmentRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private DoctorRepository doctorRepository;

	// Get today's date in the desired string format
	// LocalDate now = LocalDate.now();
	// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	// String today = now.format(formatter);

	public ResponseEntity<Map<String, String>> addAppointment(Map<String, String> appointment) {
		// Process the availability data and save it in your backend
		// Return a response with a success message
		
		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);

		Long mobileNumber = Long.parseLong(appointment.get("mobileNumber"));
		Long doctorNumber = Long.parseLong(appointment.get("doctorNumber"));
		String specialization = appointment.get("specialization");
		String date = appointment.get("date");
		String time = appointment.get("time");

		User patient = userRepository.findByMobileNumber(mobileNumber);
		Doctor doctor = doctorRepository.findByMobileNumber(doctorNumber);

		Map<String, String> response = new HashMap<>();
		
		if(appointment.containsKey("rescheduling")) {
			boolean reschedulingRequest = true;
			String createdDate = appointment.get("createdDate");
			String id = appointment.get("appointmentId");
			
			Optional<Appointment> optionalAppointment = appointmentRepository.findById(id);
			
			if(optionalAppointment.isPresent()) {
				Appointment apnmnt = optionalAppointment.get();
				
				apnmnt.setRequestStatus("Declined");
				apnmnt.setDate(date);
				apnmnt.setTime(time);
				apnmnt.setSentToDoctor(false);
				apnmnt.setDoctorApproval(false);
				apnmnt.setSentToPatient(false);
				apnmnt.setReschedulingRequest(true);
				apnmnt.setReschedulingStatus("Requested");
				apnmnt.setUpdatedDate(formattedCurrentDate);
				
				if(appointment.containsKey("oldDate")) {
					String oldDate = appointment.get("oldDate");
					String oldTime = appointment.get("oldTime");
					
					doctor.getAvailability().get(oldDate).put(oldTime, "vacant");
					doctorRepository.save(doctor);
					
					apnmnt.setDoctor(doctor);
					
					if (appointmentRepository.save(apnmnt) != null) {
						response.put("message", "Appointment Rescheduled Successfully");
						return ResponseEntity.ok(response);
					}
				}
				else {
					if (appointmentRepository.save(apnmnt) != null) {
						response.put("message", "Appointment Rescheduled Successfully");
						return ResponseEntity.ok(response);
					}
				}
			}	
		}
		else {
			if (appointmentRepository.save(new Appointment(patient, doctor, specialization, "Requested", date, time, false,
					false, false, false, "Not Applicable", false, "", formattedCurrentDate, formattedCurrentDate, true)) != null) {
				response.put("message", "Appointment Booked Successfully");
				return ResponseEntity.ok(response);
			}
		}

		response.put("message", "Sorry, Your Appointment is Not Booked. Please Try Again!");
		return ResponseEntity.ok(response);
	}

	public List<Appointment> getAppointmentStatus(Map<String, String> searchCriteria) {
		Long mobileNumber = Long.parseLong(searchCriteria.get("mobileNumber"));

		/* this is the return statement I'm using before */
		// return
		// appointmentRepository.findByPatient_MobileNumberAndTreatmentCompletedIsFalseAndDateGreaterThan(
		// mobileNumber, formattedCurrentDate);
		/* ends here */

		List<Appointment> appointments = appointmentRepository
				.findByPatient_MobileNumberAndTreatmentCompletedIsFalseAndShowIsTrue(mobileNumber);

		// return
		// appointmentRepository.findByTreatmentCompletedIsFalseAndDateGreaterThanAndPatient_MobileNumber(mobileNumber,
		// todayString);
		// return
		// appointmentRepository.findByTreatmentCompletedIsFalseAndPatient_MobileNumber(mobileNumber);

		// return
		// appointmentRepository.findByTreatmentCompletedIsFalseAndDateGreaterThan(formattedCurrentDate);
		// return appointmentRepository.findAll();

		/*Code for selecting only latest dates*/
//		List<Appointment> sortedAppointments = new ArrayList<>();
//
//		for (Appointment appointment : appointments) {
//			LocalDate date = LocalDate.parse(appointment.getDate());
//			LocalTime time = LocalTime.parse(appointment.getTime());
//
//			if (date.isBefore(currentDate) || (date.isEqual(currentDate) && time.isBefore(currentTime))) {
//				if (appointment.isReschedulingRequest()) {
//					appointment.setReschedulingStatus("Declined");
//				} else {
//					appointment.setRequestStatus("Declined");
//				}
//				appointment.setUpdatedDate(formattedCurrentDate);
//			} else {
//				sortedAppointments.add(appointment);
//			}
//		}
//
//		appointmentRepository.saveAll(appointments);
//		return sortedAppointments;
		/*ends here*/

		return appointments;
	}
	
	public List<Appointment> getCompletedAppointments(Map<String, String> searchCriteria) {
		Long mobileNumber = Long.parseLong(searchCriteria.get("mobileNumber"));

		List<Appointment> appointments = appointmentRepository
				.findByPatient_MobileNumberAndTreatmentCompletedIsTrue(mobileNumber);

		return appointments;
	}
	
	public List<Appointment> getCompletedAppointmentsOfHospital(Map<String, String> searchCriteria) {
		Long mobileNumber = Long.parseLong(searchCriteria.get("mobileNumber"));

		List<Appointment> appointments = appointmentRepository
				.findByDoctor_Hospital_Admin_MobileNumberAndTreatmentCompletedIsTrue(mobileNumber);

		return appointments;
	}


	public List<Appointment> getDoctorApprovals(Map<String, String> searchCriteria) {
		
		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);

		// Get the current time
		LocalTime currentTime = LocalTime.now();
		// Create a DateTimeFormatter for the desired format (HH:mm)
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
		// Format the current time using the formatter
		String formattedTime = currentTime.format(timeFormatter);
		
		Long mobileNumber = Long.parseLong(searchCriteria.get("mobileNumber"));

		List<Appointment> appointments = appointmentRepository
				.findByDoctor_Hospital_Admin_MobileNumberAndSentToDoctorIsTrueAndDoctorApprovalIsTrueAndSentToPatientIsFalse(mobileNumber);

		List<Appointment> sortedAppointments = new ArrayList<>();

		for (Appointment appointment : appointments) {
			LocalDate date = LocalDate.parse(appointment.getDate());
			LocalTime time = LocalTime.parse(appointment.getTime());

			if (date.isBefore(currentDate) || (date.isEqual(currentDate) && time.isBefore(currentTime))) {
				if (appointment.isReschedulingRequest()) {
					appointment.setReschedulingStatus("Declined");
				} else {
					appointment.setRequestStatus("Declined");
				}
				appointment.setSentToPatient(true);
				appointment.setUpdatedDate(formattedCurrentDate);
			} else {
				sortedAppointments.add(appointment);
			}
		}

		appointmentRepository.saveAll(appointments);

		return sortedAppointments;
	}

	public List<Appointment> getAppointmentRequests(Map<String, String> searchCriteria) {
		
		Long mobileNumber = Long.parseLong(searchCriteria.get("mobileNumber"));

		String status = "Requested";
		
		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);

		// Get the current time
		LocalTime currentTime = LocalTime.now();
		// Create a DateTimeFormatter for the desired format (HH:mm)
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
		// Format the current time using the formatter
		String formattedTime = currentTime.format(timeFormatter);

		// return
		// appointmentRepository.findByDoctor_Hospital_Admin_MobileNumberAndRequestStatusAndDateAndTimeGreaterThanEqual(mobileNumber,
		// "Requested", formattedCurrentDate, formattedTime);
		// return
		// appointmentRepository.findByDoctor_Hospital_Admin_MobileNumberAndRequestStatusAndDateGreaterThanEqualOrDateEqualsAndTimeGreaterThanEqual(mobileNumber,
		// status, formattedCurrentDate, formattedTime);

		// List<Appointment> appointments1 =
		// appointmentRepository.findByDoctor_Hospital_Admin_MobileNumberAndRequestStatusAndDateGreaterThan(mobileNumber,
		// status, formattedCurrentDate);
		// List<Appointment> appointments2 =
		// appointmentRepository.findByDoctor_Hospital_Admin_MobileNumberAndRequestStatusAndDateEqualsAndTimeGreaterThanEqual(mobileNumber,
		// status, formattedCurrentDate, formattedTime);

		/*
		 * Code returns appointments by also checking date greater than and if
		 * date equals checks time greater than or equal
		 */
		// List<Appointment> appointments1 =
		// appointmentRepository.findByDoctor_Hospital_Admin_MobileNumberAndSentToDoctorIsFalseAndDateGreaterThan(mobileNumber,
		// formattedCurrentDate);
		// List<Appointment> appointments2 =
		// appointmentRepository.findByDoctor_Hospital_Admin_MobileNumberAndSentToDoctorIsFalseAndDateEqualsAndTimeGreaterThanEqual(mobileNumber,
		// formattedCurrentDate, formattedTime);
		//
		// List<Appointment> combinedAppointments = new ArrayList<>();
		// combinedAppointments.addAll(appointments1);
		// combinedAppointments.addAll(appointments2);
		//
		// return combinedAppointments;
		/* end here */

		List<Appointment> appointments1 = appointmentRepository
				.findByDoctor_Hospital_Admin_MobileNumberAndSentToDoctorIsFalseAndRequestStatus(mobileNumber, status);
		List<Appointment> appointments2 = appointmentRepository
				.findByDoctor_Hospital_Admin_MobileNumberAndSentToDoctorIsFalseAndRequestStatusAndReschedulingRequestIsTrueAndReschedulingStatus(
						mobileNumber, "Declined", status);

		List<Appointment> combinedAppointments = new ArrayList<>();
		combinedAppointments.addAll(appointments1);
		combinedAppointments.addAll(appointments2);

		List<Appointment> sortedAppointments = new ArrayList<>();

		for (Appointment appointment : combinedAppointments) {
			LocalDate date = LocalDate.parse(appointment.getDate());
			LocalTime time = LocalTime.parse(appointment.getTime());
 
			if (date.isBefore(currentDate) || (date.isEqual(currentDate) && time.isBefore(currentTime))) {
				if (appointment.isReschedulingRequest()) {
					appointment.setReschedulingStatus("Declined");
				} else {
					appointment.setRequestStatus("Declined");
				}
				appointment.setSentToPatient(true);
				appointment.setUpdatedDate(formattedCurrentDate);
			} else {
				sortedAppointments.add(appointment);
			}
		}

		appointmentRepository.saveAll(combinedAppointments);

		return sortedAppointments;
	}

	public ResponseEntity<Map<String, String>> sendRequest(Appointment appointment) {

		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);

		appointment.setSentToDoctor(true);
		appointment.setUpdatedDate(formattedCurrentDate);

		Map<String, String> response = new HashMap<>();

		if (appointmentRepository.save(appointment) != null) {
			response.put("message", "Appointment sent successfully");
			return ResponseEntity.ok(response);
		}
		response.put("message", "Looks like the appointment detail is not present in the database");
		return ResponseEntity.ok(response);
	}

	public ResponseEntity<Map<String, String>> acceptRequest(Appointment appointment) {

		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);

		if (appointment.isReschedulingRequest()) {
			appointment.setReschedulingStatus("Accepted");
		} else {
			appointment.setRequestStatus("Accepted");
		}
		appointment.setDoctorApproval(true);
		appointment.setUpdatedDate(formattedCurrentDate);

		Map<String, String> response = new HashMap<>();

		if (appointmentRepository.save(appointment) != null) {
			response.put("message", "Appointment Accepted Successfully");
			return ResponseEntity.ok(response);
		}
		response.put("message", "Looks like the appointment detail is not present in the database");
		return ResponseEntity.ok(response);
	}

	public ResponseEntity<Map<String, String>> declineRequest(Appointment appointment) {

		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);
		
		if (appointment.isReschedulingRequest()) {
			appointment.setReschedulingStatus("Declined");
		} else {
			appointment.setRequestStatus("Declined");
		}
		appointment.setDoctorApproval(true);
		appointment.setUpdatedDate(formattedCurrentDate);

		Map<String, String> response = new HashMap<>();

		if (appointmentRepository.save(appointment) != null) {
			response.put("message", "Appointment Declined Successfully");
			return ResponseEntity.ok(response);
		}
		response.put("message", "Looks like the appointment detail is not present in the database");
		return ResponseEntity.ok(response);
	}

	public ResponseEntity<Map<String, String>> sendToPatient(Appointment appointment) {
		
		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);
		
		appointment.setSentToPatient(true);
		appointment.setUpdatedDate(formattedCurrentDate);

		Map<String, String> response = new HashMap<>();

		if (appointmentRepository.save(appointment) != null) {
			response.put("message", "Sent successfully");
			return ResponseEntity.ok(response);
		}
		response.put("message", "Looks like the appointment detail is not present in the database");
		return ResponseEntity.ok(response);
	}

	public ResponseEntity<Map<String, String>> fixAppointment(Appointment appointment) {
		
		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);
		
		appointment.setSentToPatient(true);
		appointment.setUpdatedDate(formattedCurrentDate);

		Map<String, String> response = new HashMap<>();

		Doctor doctor = doctorRepository.findByMobileNumber(appointment.getDoctor().getMobileNumber());
		if (doctor.getAvailability().get(appointment.getDate()).get(appointment.getTime()).equals("Occupied")) {
			if (appointment.isReschedulingRequest()) {
				appointment.setReschedulingStatus("Declined");
			} else {
				appointment.setRequestStatus("Declined");
			}
		} else {
			doctor.getAvailability().get(appointment.getDate()).put(appointment.getTime(), "Occupied");
			doctorRepository.save(doctor);
			appointment.setDoctor(doctor);
		}

		if (appointmentRepository.save(appointment) != null) {
			response.put("message", "Appointment Fixed Successfully");
			return ResponseEntity.ok(response);
		}
		response.put("message", "Looks like the appointment detail is not present in the database");
		return ResponseEntity.ok(response);
	}

	public ResponseEntity<Map<String, String>> removeAppointment(Appointment appointment) {
		
		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);
		
		appointment.setShow(false);
		appointment.setUpdatedDate(formattedCurrentDate);

		Map<String, String> response = new HashMap<>();

		if (appointmentRepository.save(appointment) != null) {
			response.put("message", "Removed Successfully");
			return ResponseEntity.ok(response);
		}
		response.put("message", "Looks like the appointment detail is not present in the database");
		return ResponseEntity.ok(response);
	}

	public ResponseEntity<Map<String, String>> cancelAppointment(Appointment appointment) {
		
		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);
		
		if (appointment.getRequestStatus().equals("Accepted") || appointment.getReschedulingStatus().equals("Accepted")) {
			Doctor doctor = doctorRepository.findByMobileNumber(appointment.getDoctor().getMobileNumber());
			doctor.getAvailability().get(appointment.getDate()).put(appointment.getTime(), "vacant");
			doctorRepository.save(doctor);

			appointment.setDoctor(doctor);
		}
		if (appointment.isReschedulingRequest()) {
			appointment.setReschedulingStatus("Declined");
		} else {
			appointment.setRequestStatus("Declined");
		}
		appointment.setShow(false);
		appointment.setUpdatedDate(formattedCurrentDate);

		Map<String, String> response = new HashMap<>();

		if (appointmentRepository.save(appointment) != null) {
			response.put("message", "Canceled Successfully");
			return ResponseEntity.ok(response);
		}
		response.put("message", "Looks like the appointment detail is not present in the database");
		return ResponseEntity.ok(response);
	}

	public List<Appointment> getRequestsOfDoctors(Map<String, String> searchCriteria) {
		
		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);

		// Get the current time
		LocalTime currentTime = LocalTime.now();
		// Create a DateTimeFormatter for the desired format (HH:mm)
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
		// Format the current time using the formatter
		String formattedTime = currentTime.format(timeFormatter);
		
		Long mobileNumber = Long.parseLong(searchCriteria.get("mobileNumber"));

		List<Appointment> appointments1 = appointmentRepository
				.findByDoctor_MobileNumberAndSentToDoctorIsTrueAndRequestStatus(mobileNumber, "Requested");
		List<Appointment> appointments2 = appointmentRepository
				.findByDoctor_MobileNumberAndSentToDoctorIsTrueAndReschedulingStatus(mobileNumber, "Requested");
		
		List<Appointment> combinedAppointments = new ArrayList<>();
		combinedAppointments.addAll(appointments1);
		combinedAppointments.addAll(appointments2);

		List<Appointment> sortedAppointments = new ArrayList<>();

		for (Appointment appointment : combinedAppointments) {
			LocalDate date = LocalDate.parse(appointment.getDate());
			LocalTime time = LocalTime.parse(appointment.getTime());

			if (date.isBefore(currentDate) || (date.isEqual(currentDate) && time.isBefore(currentTime))) {
				if (appointment.isReschedulingRequest()) {
					appointment.setReschedulingStatus("Declined");
				} else {
					appointment.setRequestStatus("Declined");
				}
				appointment.setSentToPatient(true);
				appointment.setUpdatedDate(formattedCurrentDate);
			} else {
				sortedAppointments.add(appointment);
			}
		}

		appointmentRepository.saveAll(combinedAppointments);

		return sortedAppointments;
	}

	public List<Appointment> getAcceptedRequests(Map<String, String> searchCriteria) {
		Long mobileNumber = Long.parseLong(searchCriteria.get("mobileNumber"));

		List<Appointment> appointments1 = appointmentRepository
				.findByDoctor_MobileNumberAndSentToPatientIsTrueAndTreatmentCompletedIsFalseAndRequestStatus(
						mobileNumber, "Accepted");
		List<Appointment> appointments2 = appointmentRepository
				.findByDoctor_MobileNumberAndSentToPatientIsTrueAndTreatmentCompletedIsFalseAndReschedulingStatus(
						mobileNumber, "Accepted");
		
		List<Appointment> combinedAppointments = new ArrayList<>();
		combinedAppointments.addAll(appointments1);
		combinedAppointments.addAll(appointments2);

		return combinedAppointments;
	}
	
	public ResponseEntity<Map<String, String>> updatePatientRecord(Appointment appointment) {

		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);

		appointment.setUpdatedDate(formattedCurrentDate);

		Map<String, String> response = new HashMap<>();

		if (appointmentRepository.save(appointment) != null) {
			response.put("message", "Patient Record Updated Successfully");
			return ResponseEntity.ok(response);
		}
		response.put("message", "Looks like the appointment detail is not present in the database");
		return ResponseEntity.ok(response);
	}
	
	public ResponseEntity<Map<String, String>> treatmentOver(Appointment appointment) {

		// Get the current date
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedCurrentDate = currentDate.format(formatter);

		appointment.setTreatmentCompleted(true);
		appointment.setUpdatedDate(formattedCurrentDate);

		Map<String, String> response = new HashMap<>();

		if (appointmentRepository.save(appointment) != null) {
			response.put("message", "Confirmation Sent Successfully");
			return ResponseEntity.ok(response);
		}
		response.put("message", "Looks like the appointment detail is not present in the database");
		return ResponseEntity.ok(response);
	}

	public List<Appointment> getAppointments() {
		System.out.println("Inside service");
		List<Appointment> appointments = appointmentRepository.findAll();
		for (Appointment appointment : appointments) {
			System.out.println(appointment);
		}
		return appointments;
	}

}

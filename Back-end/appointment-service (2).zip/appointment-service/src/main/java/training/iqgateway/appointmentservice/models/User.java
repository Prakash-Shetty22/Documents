package training.iqgateway.appointmentservice.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("Users")
public class User {
	
	@Id
	private Long mobileNumber;
	
	private String fullName;
	private String password;
	private String role;
	
	public User() {
		// TODO Auto-generated constructor stub
	}

	public User(Long mobileNumber, String fullName, String password, String role) {
		super();
		this.mobileNumber = mobileNumber;
		this.fullName = fullName;
		this.password = password;
		this.role = role;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "User [mobileNumber=" + mobileNumber + ", fullName=" + fullName + ", password=" + password + ", role="
				+ role + "]";
	}
	
}

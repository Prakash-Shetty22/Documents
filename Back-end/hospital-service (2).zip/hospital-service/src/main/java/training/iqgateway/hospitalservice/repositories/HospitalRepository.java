package training.iqgateway.hospitalservice.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import training.iqgateway.hospitalservice.models.Hospital;

public interface HospitalRepository extends MongoRepository<Hospital, String> {

	Hospital findByAdminMobileNumber(Long mobileNumber);
	
}

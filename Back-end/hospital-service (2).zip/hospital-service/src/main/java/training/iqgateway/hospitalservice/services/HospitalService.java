package training.iqgateway.hospitalservice.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import training.iqgateway.hospitalservice.models.Hospital;
import training.iqgateway.hospitalservice.repositories.HospitalRepository;

@Service
public class HospitalService {
	
	@Autowired
	private HospitalRepository hospitalRepository;
	
	public List<String> getAllLocations() {
        List<Hospital> hospitals = hospitalRepository.findAll();
        List<String> locations = new ArrayList<>();
        
        for (Hospital hospital : hospitals) {
            locations.add(hospital.getLocation());
        }
        
        return locations;
    }

	public Hospital getHospitalDetails(Map<String, String> searchCriteria) {
		Long mobileNumber = Long.parseLong(searchCriteria.get("mobileNumber"));
		
		Hospital hospital = hospitalRepository.findByAdminMobileNumber(mobileNumber);
	    if (hospital != null) {
	        System.out.println("Hospital Found: " + hospital);
	    } else {
	        System.out.println("No Hospital Found for Admin Mobile Number: " + mobileNumber);
	    }

	    return hospital;
	}
}

package training.iqgateway.doctorservice.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import training.iqgateway.doctorservice.models.Doctor;
import training.iqgateway.doctorservice.services.DoctorService;

@RestController
@CrossOrigin
@RequestMapping("/doctor")
public class DoctorController {
	
	@Autowired
	private DoctorService doctorService;
	
	@PostMapping("/availability")
	public ResponseEntity<Map<String, String>> addAvailability(@RequestBody Map<String, String> availability) {
        return doctorService.addAvailability(availability);
    }

	@PostMapping("/getAvailability")
	public Map<String, Map<String, String>> getAvailabilities(@RequestBody Map<String, String> mobileNumber) {
		return doctorService.getAvailabilities(mobileNumber);
	}
	
	@PostMapping("/sorted")
	public List<Doctor> sort(@RequestBody Map<String, String> searchCriteria) {
		return doctorService.sort(searchCriteria);
	}
	
	@PostMapping("/getBasedOnHospital")
	public List<Doctor> getBasedOnHospital(@RequestBody Map<String, String> searchCriteria) {
		return doctorService.getBasedOnHospital(searchCriteria);
	}
	
	@PostMapping("/getDetails")
	public Doctor getDoctorDetails(@RequestBody Map<String, String> searchCriteria) {
		return doctorService.getDoctorDetails(searchCriteria);
	}
}

package training.iqgateway.doctorservice.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import training.iqgateway.doctorservice.models.Doctor;

public interface DoctorRepository extends MongoRepository<Doctor, Long> {
	
	Doctor findByMobileNumber(Long mobileNumber);
	
	@Query("{'hospital.location': ?0, 'specialization': ?1}")
	List<Doctor> findByLocationAndSpecialization(String location, String specialization);
	
//	@Query(value = "{'_id': ?0}", update = "{ $unset: { 'availability.?1': '' } }")
//    void deleteAvailabilityKey(String id, String key);
	
	List<Doctor> findByHospital_Admin_MobileNumber(Long mobileNumber);

}

package training.iqgateway.doctorservice.models;

import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("Doctor")
public class Doctor {
	
	@Id
	private Long mobileNumber;
	
	private String fullName;
	private String specialization;
	private Integer age;
	private String gender;
	private Integer fee;
	private Hospital hospital;
	private Map<String, Map<String, String>> availability;
	
	public Doctor() {
		// TODO Auto-generated constructor stub
	}

	public Doctor(Long mobileNumber, String fullName, String specialization, Integer age, String gender, Integer fee,
			Hospital hospital, Map<String, Map<String, String>> availability) {
		super();
		this.mobileNumber = mobileNumber;
		this.fullName = fullName;
		this.specialization = specialization;
		this.age = age;
		this.gender = gender;
		this.fee = fee;
		this.hospital = hospital;
		this.availability = availability;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}
	
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Integer getFee() {
		return fee;
	}

	public void setFee(Integer fee) {
		this.fee = fee;
	}

	public Hospital getHospital() {
		return hospital;
	}

	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}

	public Map<String, Map<String, String>> getAvailability() {
		return availability;
	}

	public void setAvailability(Map<String, Map<String, String>> availability) {
		this.availability = availability;
	}

	@Override
	public String toString() {
		return "Doctor [mobileNumber=" + mobileNumber + ", fullName=" + fullName + ", specialization=" + specialization
				+ ", age=" + age + ", gender=" + gender + ", fee=" + fee + ", hospital=" + hospital + ", availability="
				+ availability + "]";
	}
	
}

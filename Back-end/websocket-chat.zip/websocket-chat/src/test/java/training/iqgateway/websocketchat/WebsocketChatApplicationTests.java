package training.iqgateway.websocketchat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsocketChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
